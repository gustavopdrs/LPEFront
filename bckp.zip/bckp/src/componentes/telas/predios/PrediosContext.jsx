import React from 'react';

const PrediosContext = React.createContext();

export default PrediosContext;