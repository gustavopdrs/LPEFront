const Home = () =>(
  <div>
      <h1>APP de Salas de Aula</h1>
  </div>  
);

export default Home;